# Express your thoughts about the difference between `named_entities` and `named_entities_preprocessed`
