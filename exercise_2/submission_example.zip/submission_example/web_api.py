from fastapi import FastAPI
from fastapi.responses import JSONResponse

app = FastAPI()

@app.post("/predict/")
async def predict(question: str):
    # execute your classification algorithm with question
    output = {'predicted_relation': 'RELATION'}
    return JSONResponse(content=output)